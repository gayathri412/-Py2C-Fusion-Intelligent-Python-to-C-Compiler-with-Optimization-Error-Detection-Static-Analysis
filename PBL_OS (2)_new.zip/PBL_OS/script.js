let lastResultCSV = '';
let barChartInstance = null;

function renderForm() {
  const algo = document.getElementById('algorithm').value;
  const formArea = document.getElementById('formArea');
  formArea.innerHTML = '';

  if (algo === 'fcfs' || algo === 'sjf' || algo === 'priority') {
    formArea.innerHTML += '<label>Enter number of processes:</label>';
    formArea.innerHTML += '<input type="number" id="numProcesses" onchange="generateProcessFields()">';
  } else if (algo === 'banker') {
    formArea.innerHTML = 
      `<label>Enter number of processes:</label>
       <input type="number" id="bankerNumProc">
       <label>Enter number of resources:</label>
       <input type="number" id="bankerNumRes">
       <label>Enter Allocation matrix (comma-separated rows):</label>
       <input type="text" id="allocation">
       <label>Enter Max matrix (comma-separated rows):</label>
       <input type="text" id="max">
       <label>Enter Available resources (comma-separated):</label>
       <input type="text" id="available">`;
  }
}

function generateProcessFields() {
  const num = parseInt(document.getElementById('numProcesses').value);
  const formArea = document.getElementById('formArea');

  ['Arrival', 'Burst', 'Priority'].forEach(id => {
    const show = (id === 'Priority' && document.getElementById('algorithm').value !== 'priority') ? false : true;
    if (show) {
      formArea.innerHTML += `<label>Enter ${id} Time for each process (comma-separated):</label>`;
      formArea.innerHTML += `<input type="text" id="${id.toLowerCase()}">`;
    }
  });
}

function handleFile(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    const algo = document.getElementById('algorithm').value;
    const text = e.target.result.trim();
    const preview = document.getElementById('filePreview');
    preview.innerHTML = `<strong>File loaded:</strong><br><pre>${text}</pre>`;

    if (algo === 'fcfs' || algo === 'sjf' || algo === 'priority') {
      const lines = text.split('\n');
      const arrival = lines[0].split(',').map(v => v.trim());
      const burst = lines[1].split(',').map(v => v.trim());
      const priority = lines[2] ? lines[2].split(',').map(v => v.trim()) : [];

      document.getElementById('numProcesses').value = arrival.length;
      generateProcessFields();

      setTimeout(() => {
        document.getElementById('arrival').value = arrival.join(',');
        document.getElementById('burst').value = burst.join(',');
        if (algo === 'priority' && priority.length) {
          document.getElementById('priority').value = priority.join(',');
        }
      }, 50);
    }

    if (algo === 'banker') {
      const lines = text.split('\n');
      document.getElementById('bankerNumProc').value = lines[0].trim();
      document.getElementById('bankerNumRes').value = lines[1].trim();
      document.getElementById('allocation').value = lines[2].trim();
      document.getElementById('max').value = lines[3].trim();
      document.getElementById('available').value = lines[4].trim();
    }
  };
  reader.readAsText(file);
}

function renderGanttChart(schedule) {
  const chart = document.getElementById('ganttChart');
  chart.innerHTML = '';

  schedule.forEach(proc => {
    const block = document.createElement('div');
    block.className = 'gantt-block';
    block.style.width = (proc.end - proc.start) * 20 + 'px';
    block.textContent = `P${proc.process}`;
    chart.appendChild(block);
  });
}

function generateTable(headers, rows) {
  let html = '<table><thead><tr>' + headers.map(h => `<th>${h}</th>`).join('') + '</tr></thead><tbody>';
  rows.forEach(row => {
    html += '<tr>' + row.map(cell => `<td>${cell}</td>`).join('') + '</tr>';
  });
  html += '</tbody></table>';
  return html;
}

function calculate() {
  const algo = document.getElementById('algorithm').value;
  const output = document.getElementById('output');
  const chart = document.getElementById('ganttChart');
  output.innerHTML = '';
  chart.innerHTML = '';
  lastResultCSV = '';

  let barChartData = {
    labels: [],
    datasets: [{
      label: 'Burst Time (ms)',
      data: [],
      backgroundColor: 'rgba(0, 123, 255, 0.7)',
      borderColor: 'rgba(0, 123, 255, 1)',
      borderWidth: 1
    }]
  };

  if (algo === 'fcfs' || algo === 'sjf' || algo === 'priority') {
    let arrival = document.getElementById('arrival').value.split(',').map(Number);
    let burst = document.getElementById('burst').value.split(',').map(Number);
    let n = arrival.length;
    let result = [], waiting = [], turnaround = [];
    let currentTime = 0, completed = Array(n).fill(false);
    let order = [...Array(n).keys()];

    if (algo === 'sjf') {
      let done = 0;
      while (done < n) {
        let idx = -1, minBurst = Infinity;
        for (let i = 0; i < n; i++) {
          if (!completed[i] && arrival[i] <= currentTime && burst[i] < minBurst) {
            minBurst = burst[i];
            idx = i;
          }
        }
        if (idx === -1) { currentTime++; continue; }
        completed[idx] = true;
        result.push({ process: idx, start: currentTime, end: currentTime + burst[idx] });
        turnaround[idx] = currentTime + burst[idx] - arrival[idx];
        waiting[idx] = turnaround[idx] - burst[idx];
        currentTime += burst[idx];
        done++;
      }
    } else if (algo === 'priority') {
      let priority = document.getElementById('priority').value.split(',').map(Number);
      order.sort((a, b) => priority[a] - priority[b] || arrival[a] - arrival[b]);
      for (let i of order) {
        currentTime = Math.max(currentTime, arrival[i]);
        result.push({ process: i, start: currentTime, end: currentTime + burst[i] });
        turnaround[i] = currentTime + burst[i] - arrival[i];
        waiting[i] = turnaround[i] - burst[i];
        currentTime += burst[i];
      }
    } else {
      for (let i = 0; i < n; i++) {
        currentTime = Math.max(currentTime, arrival[i]);
        result.push({ process: i, start: currentTime, end: currentTime + burst[i] });
        turnaround[i] = currentTime + burst[i] - arrival[i];
        waiting[i] = turnaround[i] - burst[i];
        currentTime += burst[i];
      }
    }

    renderGanttChart(result);
    const tableRows = order.map(i => [`P${i}`, arrival[i], burst[i], turnaround[i], waiting[i]]);
    output.innerHTML = generateTable(["Process", "Arrival", "Burst", "Turnaround", "Waiting"], tableRows);
    barChartData.labels = order.map(i => `P${i}`);
    barChartData.datasets[0].data = burst;

    if (barChartInstance) barChartInstance.destroy();
    barChartInstance = new Chart(document.getElementById('barChart'), {
      type: 'bar',
      data: barChartData,
      options: {
        scales: {
          y: { beginAtZero: true }
        }
      }
    });

    lastResultCSV = "Process,Arrival,Burst,Turnaround,Waiting\n" + tableRows.map(row => row.join(',')).join('\n');
  }

  else if (algo === 'banker') {
    const alloc = document.getElementById('allocation').value.split(',').map(row => row.trim().split(' ').map(Number));
    const max = document.getElementById('max').value.split(',').map(row => row.trim().split(' ').map(Number));
    const avail = document.getElementById('available').value.split(',').map(Number);
    const n = alloc.length, m = avail.length;

    let need = Array.from({ length: n }, (_, i) => max[i].map((val, j) => val - alloc[i][j]));
    let finish = Array(n).fill(false);
    let safeSeq = [], work = [...avail];
    let found;

    do {
      found = false;
      for (let i = 0; i < n; i++) {
        if (!finish[i] && need[i].every((val, j) => val <= work[j])) {
          for (let j = 0; j < m; j++) work[j] += alloc[i][j];
          finish[i] = true;
          safeSeq.push(i);
          found = true;
        }
      }
    } while (found);

    output.innerHTML = finish.every(Boolean)
      ? `<p><strong>Safe sequence:</strong> ${safeSeq.map(i => 'P' + i).join(' -> ')}</p>`
      : `<p style="color: red;">No safe sequence exists.</p>`;

    lastResultCSV = `Safe Sequence\n${safeSeq.join(' -> ')}`;
  }
}

function downloadCSV() {
  if (!lastResultCSV) return alert('No data to download. Run a simulation first.');
  const blob = new Blob([lastResultCSV], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'scheduling_result.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

async function downloadPDF() {
  const { jsPDF } = window.jspdf;
  const container = document.querySelector('.container');

  html2canvas(container).then(canvas => {
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'px',
      format: [canvas.width, canvas.height]
    });

    pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
    pdf.save("OS_Scheduling_Visualization.pdf");
  });
}

